#ifndef COMMON_H
#define COMMON_H

#include <cstdio>
#define logger(fmt, ...) fprintf(stdout, fmt"\n", ##__VA_ARGS__)

#endif
